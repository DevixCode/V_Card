import { DayConfig, ValentineDay } from './types';
import { Heart, Gift, Smile, Coffee, Hand, Sparkles } from 'lucide-react';

export const VALENTINE_WEEK_CONFIG: Record<string, DayConfig> = {
  '02-07': {
    id: ValentineDay.ROSE,
    dateStr: '02-07',
    title: 'Happy Rose Day 🌹',
    colors: {
      bg: 'from-red-50 to-pink-100',
      text: 'text-red-800',
      accent: 'text-red-500',
      button: 'bg-red-500 hover:bg-red-600',
    },
    icon: '🌹',
    animationType: 'roses',
  },
  '02-08': {
    id: ValentineDay.PROPOSE,
    dateStr: '02-08',
    title: 'Happy Propose Day 💍',
    colors: {
      bg: 'from-yellow-50 to-orange-100',
      text: 'text-orange-900',
      accent: 'text-orange-500',
      button: 'bg-orange-500 hover:bg-orange-600',
    },
    icon: '💍',
    animationType: 'stars',
  },
  '02-09': {
    id: ValentineDay.CHOCOLATE,
    dateStr: '02-09',
    title: 'Happy Chocolate Day 🍫',
    colors: {
      bg: 'from-amber-50 to-stone-200',
      text: 'text-amber-900',
      accent: 'text-amber-700',
      button: 'bg-amber-700 hover:bg-amber-800',
    },
    icon: '🍫',
    animationType: 'chocolates',
  },
  '02-10': {
    id: ValentineDay.TEDDY,
    dateStr: '02-10',
    title: 'Happy Teddy Day 🧸',
    colors: {
      bg: 'from-pink-50 to-rose-100',
      text: 'text-rose-900',
      accent: 'text-rose-400',
      button: 'bg-rose-400 hover:bg-rose-500',
    },
    icon: '🧸',
    animationType: 'teddies',
  },
  '02-11': {
    id: ValentineDay.PROMISE,
    dateStr: '02-11',
    title: 'Happy Promise Day 🤝',
    colors: {
      bg: 'from-blue-50 to-indigo-100',
      text: 'text-indigo-900',
      accent: 'text-indigo-500',
      button: 'bg-indigo-500 hover:bg-indigo-600',
    },
    icon: '🤝',
    animationType: 'stars',
  },
  '02-12': {
    id: ValentineDay.HUG,
    dateStr: '02-12',
    title: 'Happy Hug Day 🤗',
    colors: {
      bg: 'from-orange-50 to-red-100',
      text: 'text-orange-800',
      accent: 'text-orange-500',
      button: 'bg-orange-500 hover:bg-orange-600',
    },
    icon: '🤗',
    animationType: 'hearts',
  },
  '02-13': {
    id: ValentineDay.KISS,
    dateStr: '02-13',
    title: 'Happy Kiss Day 💋',
    colors: {
      bg: 'from-pink-100 to-rose-200',
      text: 'text-pink-900',
      accent: 'text-pink-600',
      button: 'bg-pink-600 hover:bg-pink-700',
    },
    icon: '💋',
    animationType: 'kisses',
  },
  '02-14': {
    id: ValentineDay.VALENTINE,
    dateStr: '02-14',
    title: 'Happy Valentine\'s Day ❤️',
    colors: {
      bg: 'from-red-100 to-rose-300',
      text: 'text-red-900',
      accent: 'text-red-600',
      button: 'bg-red-600 hover:bg-red-700',
    },
    icon: '❤️',
    animationType: 'hearts',
  },
  'default': {
    id: ValentineDay.NONE,
    dateStr: 'default',
    title: 'Sharing the Love 💖',
    colors: {
      bg: 'from-pink-50 to-purple-100',
      text: 'text-purple-900',
      accent: 'text-purple-500',
      button: 'bg-purple-500 hover:bg-purple-600',
    },
    icon: '✨',
    animationType: 'hearts',
  }
};
