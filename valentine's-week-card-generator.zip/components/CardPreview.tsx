import React from 'react';
import { CardData, DayConfig } from '../types';
import { motion } from 'framer-motion';

interface CardPreviewProps {
  data: CardData;
  config: DayConfig;
  className?: string;
}

const CardPreview: React.FC<CardPreviewProps> = ({ data, config, className = '' }) => {
  const fontClass = data.fontStyle === 'handwriting' 
    ? 'font-handwriting' 
    : data.fontStyle === 'serif' 
      ? 'font-serif' 
      : 'font-sans';

  return (
    <div className={`relative w-full max-w-md mx-auto aspect-[3/4] rounded-2xl shadow-2xl overflow-hidden bg-white p-2 ${className}`}>
      {/* Card Border/Frame */}
      <div className={`w-full h-full rounded-xl border-4 border-double ${config.colors.accent.replace('text-', 'border-')} p-6 flex flex-col items-center justify-between relative bg-gradient-to-br ${config.colors.bg} opacity-90`}>
        
        {/* Decorative Header */}
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center w-full"
        >
          <div className="text-4xl mb-2 filter drop-shadow-sm">{config.icon}</div>
          <h2 className={`text-2xl font-serif font-bold ${config.colors.text} tracking-wide`}>
            {config.title}
          </h2>
        </motion.div>

        {/* Message Body */}
        <motion.div 
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.2 }}
          className="flex-grow flex flex-col justify-center items-center text-center w-full my-4"
        >
          <div className={`${fontClass} text-xl md:text-2xl leading-relaxed ${config.colors.text} break-words w-full px-2`}>
            "{data.message || "Your beautiful message will appear here..."}"
          </div>
        </motion.div>

        {/* Footer Names */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="w-full text-center"
        >
           <div className={`text-sm uppercase tracking-widest ${config.colors.accent} mb-1 font-bold`}>
            For My Valentine
          </div>
          <div className="text-xl font-bold font-serif text-gray-800">
            {data.to}
          </div>
          <div className="my-2 h-px w-16 bg-gray-300 mx-auto"></div>
          <div className="text-sm text-gray-500 italic">
            Sent with love by
          </div>
          <div className="text-lg font-serif text-gray-700">
            {data.from}
          </div>
        </motion.div>

        {/* Absolute Background Patterns (Subtle) */}
        <div className="absolute top-0 left-0 w-full h-full pointer-events-none opacity-5 z-[-1]">
             <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
                <defs>
                    <pattern id="heart-pattern" x="0" y="0" width="20" height="20" patternUnits="userSpaceOnUse">
                        <path d="M10 15.27L8.55 13.95C3.4 9.28 0 6.2 0 2.5C0 0.95 1.15 -0.2 2.75 -0.2C3.65 -0.2 4.5 0.22 5.25 1.1C6 0.22 6.85 -0.2 7.75 -0.2C9.35 -0.2 10.5 0.95 10.5 2.5C10.5 6.2 7.1 9.28 1.95 13.95L0.5 15.27Z" fill="currentColor" transform="scale(0.8) translate(5,5)"/>
                    </pattern>
                </defs>
                <rect x="0" y="0" width="100%" height="100%" fill="url(#heart-pattern)" className={config.colors.text} />
            </svg>
        </div>
      </div>
    </div>
  );
};

export default CardPreview;
