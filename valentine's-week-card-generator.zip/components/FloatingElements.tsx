import React from 'react';
import { motion } from 'framer-motion';

interface FloatingElementsProps {
  type: 'hearts' | 'roses' | 'teddies' | 'chocolates' | 'stars' | 'kisses';
}

const FloatingElements: React.FC<FloatingElementsProps> = ({ type }) => {
  // Generate random positions for floating elements
  const elements = Array.from({ length: 15 }).map((_, i) => ({
    id: i,
    left: Math.random() * 100,
    delay: Math.random() * 5,
    duration: 5 + Math.random() * 5,
    size: 10 + Math.random() * 20,
  }));

  const getEmoji = () => {
    switch (type) {
      case 'roses': return '🌹';
      case 'teddies': return '🧸';
      case 'chocolates': return '🍫';
      case 'stars': return '✨';
      case 'kisses': return '💋';
      case 'hearts':
      default: return '❤️';
    }
  };

  const emoji = getEmoji();

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
      {elements.map((el) => (
        <motion.div
          key={el.id}
          initial={{ y: '110vh', x: `${el.left}vw`, opacity: 0 }}
          animate={{
            y: '-10vh',
            opacity: [0, 1, 1, 0],
            rotate: [0, 360],
          }}
          transition={{
            duration: el.duration,
            repeat: Infinity,
            delay: el.delay,
            ease: "linear",
          }}
          style={{
            position: 'absolute',
            fontSize: `${el.size}px`,
          }}
        >
          {emoji}
        </motion.div>
      ))}
    </div>
  );
};

export default FloatingElements;
