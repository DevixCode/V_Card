import React, { useEffect, useState } from 'react';
import { CardData, DayConfig } from '../types';
import { VALENTINE_WEEK_CONFIG } from '../constants';
import { isCardExpired } from '../utils';
import CardPreview from './CardPreview';
import { Clock, AlertCircle, Heart } from 'lucide-react';
import { motion } from 'framer-motion';

interface ViewCardProps {
  data: CardData;
  onCompose: () => void;
}

const ViewCard: React.FC<ViewCardProps> = ({ data, onCompose }) => {
  const [expired, setExpired] = useState(false);
  const [dayConfig, setDayConfig] = useState<DayConfig>(VALENTINE_WEEK_CONFIG['default']);

  useEffect(() => {
    // Check expiry
    if (isCardExpired(data)) {
      setExpired(true);
    }
    
    // Determine theme based on the day saved in card data
    // We try to find the config that matches the ID
    const config = Object.values(VALENTINE_WEEK_CONFIG).find(c => c.id === data.day) || VALENTINE_WEEK_CONFIG['default'];
    setDayConfig(config);
  }, [data]);

  if (expired) {
    return (
      <div className="max-w-md mx-auto p-8 text-center bg-white/90 backdrop-blur-md rounded-3xl shadow-xl mt-20 border border-red-100">
        <motion.div 
          initial={{ scale: 0 }} 
          animate={{ scale: 1 }}
          className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-6"
        >
          <Clock className="w-10 h-10 text-gray-400" />
        </motion.div>
        <h2 className="text-2xl font-bold text-gray-800 mb-2">This wish has melted away 💔</h2>
        <p className="text-gray-500 mb-8">
          Valentine's wishes are fleeting like chocolate in the sun. This card has expired.
        </p>
        <button
          onClick={onCompose}
          className="bg-pink-500 hover:bg-pink-600 text-white font-bold py-3 px-8 rounded-full shadow-lg transition-all transform hover:-translate-y-1"
        >
          Create a New Card
        </button>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 pb-20">
      <motion.div
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, type: 'spring' }}
      >
        <CardPreview data={data} config={dayConfig} />
      </motion.div>

      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1 }}
        className="mt-8 text-center"
      >
        <p className="text-gray-600 mb-4 bg-white/60 backdrop-blur py-2 px-4 rounded-full text-sm inline-block">
          Received a lovely wish? 
        </p>
        <br />
        <button
          onClick={onCompose}
          className={`bg-white hover:bg-gray-50 text-gray-800 font-bold py-3 px-8 rounded-full shadow-lg transition-all transform hover:-translate-y-1 flex items-center gap-2 mx-auto ring-1 ring-gray-200`}
        >
          <Heart className="w-5 h-5 text-pink-500 fill-pink-500" /> Reply with a Card
        </button>
      </motion.div>
    </div>
  );
};

export default ViewCard;
