export enum ValentineDay {
  ROSE = 'Rose Day',
  PROPOSE = 'Propose Day',
  CHOCOLATE = 'Chocolate Day',
  TEDDY = 'Teddy Day',
  PROMISE = 'Promise Day',
  HUG = 'Hug Day',
  KISS = 'Kiss Day',
  VALENTINE = 'Valentine\'s Day',
  NONE = 'Just Love',
}

export interface CardData {
  from: string;
  to: string;
  message: string;
  day: ValentineDay;
  timestamp: number; // Creation timestamp for expiry logic
  themeId?: string; // For future extensibility
  fontStyle?: 'handwriting' | 'serif' | 'sans';
}

export interface DayConfig {
  id: ValentineDay;
  dateStr: string; // e.g., "02-07"
  title: string;
  colors: {
    bg: string; // Tailwind class
    text: string; // Tailwind class
    accent: string; // Tailwind class
    button: string; // Tailwind class
  };
  icon: string; // Lucide icon name or emoji
  animationType: 'hearts' | 'roses' | 'teddies' | 'chocolates' | 'stars' | 'kisses';
}
