import { VALENTINE_WEEK_CONFIG } from './constants';
import { CardData, DayConfig } from './types';

export const getCurrentDayConfig = (overrideDate?: Date): DayConfig => {
  const now = overrideDate || new Date();
  const month = (now.getMonth() + 1).toString().padStart(2, '0');
  const day = now.getDate().toString().padStart(2, '0');
  const key = `${month}-${day}`;

  return VALENTINE_WEEK_CONFIG[key] || VALENTINE_WEEK_CONFIG['default'];
};

export const encodeCardData = (data: CardData): string => {
  try {
    const jsonString = JSON.stringify(data);
    return btoa(encodeURIComponent(jsonString));
  } catch (e) {
    console.error("Failed to encode card data", e);
    return '';
  }
};

export const decodeCardData = (encoded: string): CardData | null => {
  try {
    const jsonString = decodeURIComponent(atob(encoded));
    return JSON.parse(jsonString);
  } catch (e) {
    console.error("Failed to decode card data", e);
    return null;
  }
};

export const isCardExpired = (data: CardData): boolean => {
  const createdDate = new Date(data.timestamp);
  const now = new Date();

  // Create expiry date: 11:59 PM on the creation day
  const expiryDate = new Date(createdDate);
  expiryDate.setHours(23, 59, 59, 999);

  return now > expiryDate;
};

export const generateLink = (data: CardData): string => {
  const encoded = encodeCardData(data);
  const baseUrl = window.location.href.split('#')[0];
  return `${baseUrl}#/view?data=${encoded}`;
};
