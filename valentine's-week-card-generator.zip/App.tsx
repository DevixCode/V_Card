import React, { useEffect, useState } from 'react';
import { decodeCardData, getCurrentDayConfig } from './utils';
import { CardData, DayConfig } from './types';
import FloatingElements from './components/FloatingElements';
import CreateCard from './components/CreateCard';
import ViewCard from './components/ViewCard';
import { HeartHandshake } from 'lucide-react';

// Simple Hash Router Implementation
const App: React.FC = () => {
  const [viewMode, setViewMode] = useState<'create' | 'view'>('create');
  const [viewData, setViewData] = useState<CardData | null>(null);
  const [currentTheme, setCurrentTheme] = useState<DayConfig>(getCurrentDayConfig());

  useEffect(() => {
    // Handle URL Hash change for routing
    const handleHashChange = () => {
      const hash = window.location.hash;
      if (hash.startsWith('#/view')) {
        const params = new URLSearchParams(hash.split('?')[1]);
        const encodedData = params.get('data');
        if (encodedData) {
          const decoded = decodeCardData(encodedData);
          if (decoded) {
            setViewData(decoded);
            setViewMode('view');
            return;
          }
        }
      }
      // Default to create
      setViewMode('create');
      setViewData(null);
    };

    // Listen
    window.addEventListener('hashchange', handleHashChange);
    // Initial check
    handleHashChange();

    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  // Update theme based on view mode
  useEffect(() => {
    if (viewMode === 'create') {
      // Dynamic theme handled inside CreateCard usually, but background can track current real day
      setCurrentTheme(getCurrentDayConfig()); 
    } else if (viewMode === 'view' && viewData) {
      // In view mode, try to match the theme of the card
      // We need to fetch the config that corresponds to the card's day ID
      // This logic is slightly duplicated in ViewCard for the card itself, but here for the background
      // Note: We might just let the background be the current day or neutral for viewers?
      // Let's keep it consistent with the card content for immersion.
      // But finding the key from ID is hard without reverse lookup. 
      // For simplicity, let's use the 'hearts' default or try to match animationType.
      
      // Actually, FloatingElements takes a type. Let's pass that down.
    }
  }, [viewMode, viewData]);

  // Determine animation type for background
  const getAnimationType = () => {
    if (viewMode === 'view' && viewData) {
      // Simple heuristic if we can't map perfectly back to config
      if (viewData.day.includes('Rose')) return 'roses';
      if (viewData.day.includes('Teddy')) return 'teddies';
      if (viewData.day.includes('Chocolate')) return 'chocolates';
      if (viewData.day.includes('Star') || viewData.day.includes('Promise')) return 'stars';
      if (viewData.day.includes('Kiss')) return 'kisses';
      return 'hearts';
    }
    return currentTheme.animationType;
  };

  return (
    <div className={`min-h-screen relative transition-colors duration-1000 bg-gradient-to-br ${viewMode === 'create' ? currentTheme.colors.bg : 'from-pink-50 to-red-50'}`}>
      
      {/* Background Animation */}
      <FloatingElements type={getAnimationType()} />

      {/* Header / Nav */}
      <nav className="relative z-10 p-6 flex justify-between items-center max-w-7xl mx-auto">
        <div className="flex items-center gap-2 cursor-pointer" onClick={() => window.location.hash = ''}>
          <div className="bg-white p-2 rounded-full shadow-md text-pink-500">
            <HeartHandshake size={24} />
          </div>
          <span className="font-serif font-bold text-xl text-gray-800 tracking-wide hidden sm:block">
            Valentine's Week
          </span>
        </div>
        
        {viewMode === 'create' && (
           <div className="text-sm font-medium px-4 py-1 bg-white/50 backdrop-blur rounded-full text-gray-600 border border-white/50 shadow-sm">
             {currentTheme.dateStr === 'default' ? "Love is in the air" : `Today is ${currentTheme.id}`}
           </div>
        )}
      </nav>

      {/* Main Content */}
      <main className="relative z-10 w-full">
        {viewMode === 'create' ? (
          <CreateCard />
        ) : (
          viewData && <ViewCard data={viewData} onCompose={() => window.location.hash = ''} />
        )}
      </main>

      {/* Footer */}
      <footer className="relative z-10 py-8 text-center text-gray-500 text-sm">
        <p>&copy; {new Date().getFullYear()} Valentine's Card Generator. Made with 💖</p>
      </footer>

    </div>
  );
};

export default App;
