import { GoogleGenAI } from "@google/genai";
import { ValentineDay } from '../types';

const getClient = () => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    console.error("API_KEY is missing from environment");
    return null;
  }
  return new GoogleGenAI({ apiKey });
};

export const generateRomanticMessage = async (day: ValentineDay, toName: string, fromName: string): Promise<string> => {
  const client = getClient();
  if (!client) {
    return "Happy Valentine's Week! Sending you lots of love.";
  }

  try {
    const prompt = `Write a short, cute, and romantic message (maximum 200 characters) for ${day}. The message is for "${toName}" from "${fromName}". Make it sweet and suitable for a greeting card. Do not include quotes around the message.`;
    
    const response = await client.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
    });

    return response.text?.trim() || `Happy ${day}, ${toName}! Love, ${fromName}`;
  } catch (error) {
    console.error("Error generating message:", error);
    return `Happy ${day}, ${toName}! Love, ${fromName}`; // Fallback
  }
};
